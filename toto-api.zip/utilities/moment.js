var moment = require('moment-timezone')

moment.tz.setDefault('Asia/Seoul')

module.exports = moment
