const methods = {
  bootstrap () {
    // console.log('Hello Jobs')
  }
}

methods.bootstrap()
